package com.techm.ms.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.techm.ms.model.Account;
import com.techm.ms.model.User;

@Service("userService")
public class UserServiceImpl implements UserService {
	
	private static List<User> users;
	static {
		users = DummyUsers();
	}
	
	private static List<User> DummyUsers() {
		List<User> users = new ArrayList<User>();
		users.add(new User(1,"abc",30,101));
		users.add(new User(2,"pqr",40,102));
		users.add(new User(3,"ijk",50,103));
		return users;
	}
	
	@Override
	public void saveUser(User user) {
		users.add(user);
	}

	@Override
	public List<User> findAllUser() {
		return users;
	}

	@Override
	public User findById(long id) {
		for(User user: users) {
			if(user.getId() == id) {
				return user;
			}
		}
		return null;
	}

}
