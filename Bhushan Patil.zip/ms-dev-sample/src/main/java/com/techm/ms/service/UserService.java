package com.techm.ms.service;

import java.util.List;

import com.techm.ms.model.Account;
import com.techm.ms.model.User;

public interface UserService {
	List<User> findAllUser();
	User findById(long id);
	void saveUser(User user);
}
